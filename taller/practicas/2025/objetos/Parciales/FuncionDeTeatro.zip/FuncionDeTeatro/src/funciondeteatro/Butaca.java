/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funciondeteatro;

/**
 *
 * @author Lara
 */
public class Butaca {
    private String descriptor;
    private double precio;
    private boolean ocupada;
    
    public Butaca (int fila, int numero) {
        this.descriptor = "Butaca " + fila + ", " + numero;
        this.precio = 800 + 100 * fila + 50 * numero;
        this.ocupada = false;
    }
    
    @Override
        public String toString() {
            String estado;
            if (ocupada) {
                estado = "Ocupada";
            } else {
                estado = "Libre";
            }
            return "(" + descriptor + ", " + precio + ", " + estado + ")";
         }

     public void desocupar () {
        this.ocupada = false;
    }
    public void ocupar () {
        this.ocupada = true;
    }
    public double getPrecio() {
        return precio;
    }
            
}
