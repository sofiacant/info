/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funciondeteatro;

/**
 *
 * @author Lara
 */
public class Funcion {
    private String titulo;
    private String fecha;
    private String hora;
    private Butaca [][] sala;
    private int filas;
    private int butacasPorFila;
    public Funcion (String unTitulo, String unaFecha, String unaHora, int N, int M) {
        this.titulo = unTitulo;
        this.fecha = unaFecha;
        this.hora = unaHora;
        this.filas = N;
        this.butacasPorFila = M;
        this.sala = new Butaca [filas][butacasPorFila];
        
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < butacasPorFila; j++) {
                sala[i][j] = new Butaca(i + 1, j + 1);
            }
        }
    }
    
    public double ocuparButaca(int fila, int butaca) {
            Butaca b = sala[fila - 1][butaca - 1];
            b.ocupar();
            return b.getPrecio();
    }
    
    public void desocuparFila(int fila) {
        for(int j = 0 ; j < butacasPorFila; j++) {
            sala[fila - 1][j].desocupar();
        }
    }
    
    public String mostrarButaca(int numeroButaca) {
        String resultado = "";
        if (numeroButaca >= 1 && numeroButaca <= butacasPorFila) {
            for(int i = 0 ; i < filas ; i++) {
                resultado = resultado + sala[i][numeroButaca - 1].toString();
            }
        } else {
            resultado = "Fuera de rango, no se encontro la butaca ingresada...";
        }
        return resultado;
    }
    
    @Override
   public String toString() {
        String texto = "Función: " + titulo + " | Fecha: " + fecha + " | Hora: " + hora + "\n";
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < butacasPorFila; j++) {
                texto = texto + sala[i][j].toString() + "\n";
            }
        }
        return texto;
    }
}
