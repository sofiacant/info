/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package funciondeteatro;

/**
 *
 * @author Lara
 */
public class FuncionDeTeatro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcion f = new Funcion("Hamlet", "14/10/2022", "20:30", 3, 4);

        System.out.println("Ocupando butacas...");
        System.out.println("Precio: $" + f.ocuparButaca(1, 1));
        System.out.println("Precio: $" + f.ocuparButaca(2, 3));

        System.out.println("\nButacas número 2 de cada fila:");
        System.out.println(f.mostrarButaca(2));

        System.out.println("\nDesocupando fila 1...");
        f.desocuparFila(1);

        System.out.println("\nEstado completo de la función:");
        System.out.println(f.toString());
    }
}

   