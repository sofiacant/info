/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica3inc4;

/**
 *
 * @author Sofia C
 */
public class Cliente {
    private String nombre;
    private int dni;
    private int edad;   

    public Cliente(String nombre, int dni, int edad) {
        this.nombre = nombre;
        this.dni = dni;
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Cliente:" + " Nombre: " + nombre + ", dni: " + dni + ", edad: " + edad + "\n";
    }
    
     
}
 