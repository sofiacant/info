  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica3inc4;

/**
 *
 * @author Sofia C
 */
public class Hotel {
    private Habitacion[] hotel;
    private int N;

    public Hotel(int N) {
        this.N = N;
        hotel= new Habitacion[N];
        for (int i = 0; i < N; i++) {
            hotel[i]= new Habitacion();
        }
    }
    
    public void ingresarCliente(Cliente c, int X){
        hotel[X-1].setCliente(c);
        hotel[X-1].setOcupada();
    }
    
    public void aumentarPrecioHab(double monto){
        for (int i = 0; i < N; i++) {
            hotel[i].aumentarPrecio(monto);
        }
    }


    public String toString() {
        String aux= "Hotel:" +"\n";
        for (int i = 0; i < N; i++) {
            aux+="Habitacion "+ (i+1)+ hotel[i].toString();
        }
        return aux;
    }
    
    
}
