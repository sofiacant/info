/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica3inc4;
import PaqueteLectura.GeneradorAleatorio; 
/**
 *
 * @author Sofia C
 */
public class Habitacion {
    private double costoNoche;
    private boolean ocupada;
    private Cliente cli;


    public Habitacion() {
        this.ocupada=false;
        this.costoNoche= 2000+ GeneradorAleatorio.generarDouble(6000);
    }
    
    public void setCliente(Cliente c){
        cli=c;
    }
    
    public void setOcupada(){
        ocupada=true;
    }

    public boolean isOcupada() {
        return ocupada;
    }
    
    
    public void aumentarPrecio(double monto){
        this.costoNoche+= monto;
    }
    
    

    public String toString() {
        String aux= "Costo: " + String.format("%.2f",costoNoche) + ", ocupada: " + ocupada + "\n";
        if(ocupada){
            aux+="--"+ cli.toString();
        }
        return aux+ "\n";
    }
    
    
    
}   
