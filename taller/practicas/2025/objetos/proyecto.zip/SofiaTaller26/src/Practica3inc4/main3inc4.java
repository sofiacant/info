
package Practica3inc4;

/**
 *
 * @author Sofia C
 */
public class main3inc4 {

  
    public static void main(String[] args) {
       Hotel hotel=new Hotel(6);
       
       Cliente cli1= new Cliente("Mara", 423534, 19);
       Cliente cli2= new Cliente("Sofia", 412321, 12);
       Cliente cli3= new Cliente("Pia", 42857, 73);
       Cliente cli4= new Cliente("Maria", 745665, 32);
       
       hotel.ingresarCliente(cli1, 2);
       hotel.ingresarCliente(cli2, 1);
       hotel.ingresarCliente(cli3, 5);
       hotel.ingresarCliente(cli4, 3);
       
        System.out.println(hotel.toString());
       
       
       hotel.aumentarPrecioHab(1500);
       
        System.out.println(hotel.toString());
        
    }
    
}
