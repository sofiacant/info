/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica5ej3;

/**
 *
 * @author Sofia C
 */
public abstract class Recital {
    private String nombreBanda;
    private String listaTemas[];
    private int dimF;
    private int dimL;

    public Recital(String nombreBanda, int cantTemas) {
        this.nombreBanda = nombreBanda;
        this.dimF = cantTemas;
        this.dimL=0;
        listaTemas= new String[dimF];
    }
    
    public void agregarTema(String tema){  //si no aclara asumir que hay lugar?
        listaTemas[dimL]=tema;
        dimL++;
    }
    
    public String actuar(){
        String aux="y ahora tocaremos...";
        for (int i = 0; i < dimL; i++) { 
            System.out.println(aux);
            System.out.println(listaTemas[i]);
        }
        return aux;
    }
    
    public abstract double calcularCosto();

    
    
    
    
    
    
}
