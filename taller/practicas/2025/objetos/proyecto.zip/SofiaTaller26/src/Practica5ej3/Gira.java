/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica5ej3;

/**
 *
 * @author Sofia C
 */
public class Gira extends Recital {
    private String nombreGira;
    private Fecha vFechas[];
    private int fechaActual;
    private int dimF;
    private int dimL;

    public Gira(String nombreGira, int cantFechas, String nombreBanda, int cantTemas) {
        super(nombreBanda, cantTemas);
        this.nombreGira = nombreGira;
        this.dimF = cantFechas;
        this.dimL=0;
        vFechas= new Fecha[dimF];
    }
    
    public void agregarTema(String tema){
        super.agregarTema(tema);
    }
    
    public String actuar(){
        String aux="Buenas noches..."+vFechas[fechaActual].getCiudad()+ "\n";
        fechaActual++;
        aux+= super.actuar();
        return aux;
    }
    
    public void agregarFecha(Fecha f){
        vFechas[dimL]= f;
        dimL++;
    }
    
    public double calcularCosto(){
        return dimL*30000;
    }
    
    
    
    
    
    
}
