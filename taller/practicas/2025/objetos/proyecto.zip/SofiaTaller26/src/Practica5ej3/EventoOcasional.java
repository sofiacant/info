/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica5ej3;

/**
 *
 * @author Sofia C
 */
public class EventoOcasional extends Recital{
    private String motivo;
    private String nombreContratante;
    private int diaEvento;

    public EventoOcasional(String motivo, String nombreContratante, int diaEvento, String nombreBanda, int cantTemas) {
        super(nombreBanda, cantTemas);
        this.motivo = motivo;
        this.nombreContratante = nombreContratante;
        this.diaEvento = diaEvento;
    }
   
     public void agregarTema(String tema){
        super.agregarTema(tema);
    }
     
    public String actuar(){
        String aux=" ";
        if (motivo.equals("a beneficio")){
            aux+= "Recuerden colaborar con..."+ nombreContratante;
        }else if(motivo.equals("show de tv")){
                aux+= "Saludos amigos televidentes ";
        }else if(motivo.equals("Show privado")){
                aux+= "Un feliz cumpleaños para...";
        }
        aux+=super.actuar();
        return aux;
    }
    
    public double calcularCosto(){
        double aux=-1;
        if(this.motivo.equals("a beneficio")) aux=0;
        if(this.motivo.equals("show de tv")) aux=50000;
        if(this.motivo.equals("Show privado")) aux=150000;
        return aux;
    }
    
}
