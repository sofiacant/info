package parcialUniversidad;

/**
 *
 * @author Sofia C
 */
public class Universidad {
    private int añoA;
    private int añoB;
    private int filas;
    private int dimCol;
    private Examen examenes[][]; //comento que la entiendo ya inciializada en null
    private int dimLAño[];

    public Universidad(int N) {
        this.añoA=2000;
        this.añoB=2025;
        this.dimCol = N;
        this.filas= añoB-añoA+1;
        examenes= new Examen[filas][dimCol];
        
        inicializarVDimL(); //inicializar en 0 

    }

    private void inicializarVDimL(){
        dimLAño= new int[filas];
        for (int i = 0; i < filas; i++) {
            dimLAño[i]=0;
        }
    }

    public void agregarExamen(Examen ex, int año){      //ver si hace falta verificar if (f >= 0 && f < filas && dimLAño[f] < dimCol)si
        examenes[año-this.añoA][dimLAño[año-añoA]]= ex;
        dimLAño[año-añoA]++;
    }


    public int cantidadExamenesAlumno(String legajo, int año){
        int cant=0;
        int j=0; 
        while( j< dimLAño[año-añoA] ){
            if(examenes[año-this.añoA][j].getAlumno().buscarAlu(legajo)){
                cant++;
            } 
            j++;
        }
        return cant;
    }
    

    public int mayorModalidad(String modalidad){
        int cantMax=-1;
        int añoMax=-1;
        int cant;
        for (int i = 0; i < filas; i++) {
            cant=0;
            for (int j = 0; j < dimLAño[i]; j++) {
                if(examenes[i][j].esIgualModalidad(modalidad)){
                    cant++;
                }
            }
            if (cant> cantMax){
                cantMax= cant;
                añoMax=i;
            }
        }
        return (añoMax+añoA);
    }

    public String infoExamenes(double calif){
        String str="";
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < dimLAño[i]; j++) {
                if(examenes[i][j].cumpleExamen(calif)){
                    str+= examenes[i][j].toString()+ "\n";
                }
            }
        }
        return str;
    }        
}

