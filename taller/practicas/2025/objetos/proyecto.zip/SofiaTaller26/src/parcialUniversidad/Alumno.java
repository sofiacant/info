/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialUniversidad;

/**
 *
 * @author Sofia C
 */
public class Alumno {
    private String nombre;
    private String apellido;
    private String legajo;

    public Alumno(String nombre, String apellido, String legajo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.legajo = legajo;
    }

    public String getLegajo() {
        return legajo;
    }

    public boolean buscarAlu(String leg){
        boolean aux=false;
        if(this.legajo.equals(leg)){
            aux=true;
        }
        return aux;
    }

    @Override
    public String toString() {
        return "Alumno " + " nombre: " + nombre + ", apellido: " + apellido + ", legajo: " + legajo ;
    }
    
}
