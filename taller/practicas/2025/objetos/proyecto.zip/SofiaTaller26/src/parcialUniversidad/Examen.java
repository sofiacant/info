/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialUniversidad;

/**
 *
 * @author Sofia C
 */
public class Examen {
    private int mes;
    private int año;
    private double calificacion;
    private String modalidad;
    private Alumno alumno;


    public Examen(int mes, int año, double calificacion, String modalidad, Alumno alumno) {
        this.mes = mes;
        this.año = año;
        this.calificacion = calificacion;
        this.modalidad = modalidad;
        this.alumno = alumno;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public String getModalidad() {
        return modalidad;
    }

    public boolean esIgualModalidad(String mod){
        boolean aux=false;
        if(this.modalidad.equals(mod)){
            aux=true;
        }
        return aux;
    }

    public boolean cumpleExamen(double calif){
        boolean aux=false;
        if(this.calificacion>= calif){
            aux=true;
        }
        return aux;
    }

    @Override
    public String toString() {
        return alumno.toString()+ " mes: " + mes + " año " + año + ", calificacion: " + calificacion ;
    }
}
