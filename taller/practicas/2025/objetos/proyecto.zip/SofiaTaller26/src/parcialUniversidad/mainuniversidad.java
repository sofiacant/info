package parcialUniversidad;
import PaqueteLectura.Lector;
/**
 *
 * @author Sofia C
 */
public class mainuniversidad {

    public static void main(String[] args) {
         Universidad u= new Universidad(200);

        Alumno a1= new Alumno("Sofia", "Canteros", "654645");
        Alumno a2= new Alumno("Maria", "Gonzalez", "423442");
        Alumno a3= new Alumno("Rosa", "Cano", "123185");
        Alumno a4= new Alumno("Azul", "Gomez", "867454");

        Examen e1= new Examen(1, 2022, 9.6, "oral", a1);
        Examen e2= new Examen(4, 2021, 7.5, "escrito", a2);
        Examen e3= new Examen(8, 2008, 7, "escrito", a3);
        Examen e4= new Examen(11, 2024, 6.2 , "trabajo integrador", a4);

        u.agregarExamen(e1, 2022);
        u.agregarExamen(e2, 2021);
        u.agregarExamen(e3, 2008);
        u.agregarExamen(e4, 2024);

        System.out.println(u.cantidadExamenesAlumno("423442", 2021));

        System.out.println("Ingrese un legajo de alumno");
        String alu= Lector.leerString();
        System.out.println("Ingrese un año");
        int año= Lector.leerInt();

        System.out.println(u.mayorModalidad("escrita"));
        System.out.println(u.infoExamenes(7));

    }
    
}
