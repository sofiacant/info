
package Adicionales2;
import PaqueteLectura.Lector;

public class ej2 {

   
    public static void main(String[] args) {
        int N= Lector.leerInt();
        int M= Lector.leerInt();
        Partido[][] torneo= new Partido [N][M];
        
        int fecha= Lector.leerInt();
        while(fecha != 0){
            String local= Lector.leerString();
            String visitante= Lector.leerString();
            int golesLocal= Lector.leerInt();
            int golesVisitante= Lector.leerInt();
            
            torneo[fecha][0]= new Partido(local,visitante, golesLocal,golesVisitante);
            fecha= Lector.leerInt();
            
            
        }
        
        
        
                
    }
    
}
