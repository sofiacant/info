
package Adicionales2;
import PaqueteLectura.Lector;
public class ej1Adautos {

  
    public static void main(String[] args) {
        
        int N= Lector.leerInt();
        Auto [][]estacionamiento = new Auto[N][N];
        
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                estacionamiento[i][j]= null;
            }   
        }
        
        int cantAutos=5;
        int plaza, piso;
        int patente;
        String dueño;
         // INCISO B
        for (int i = 0; i < cantAutos; i++) {
            
            System.out.println("Ingrese patente: ");
            patente= Lector.leerInt();
            System.out.println("Ingrese dueño del auto: ");
            dueño= Lector.leerString();
            System.out.println("Ingrese numero de piso");
            piso= Lector.leerInt();
            System.out.println("Ingrese numero de plaza");
            plaza= Lector.leerInt();       
            Auto au= new Auto(patente, dueño);
            estacionamiento[piso-1][plaza-1]= au; 
        }
      //INCISO C i. 
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if(estacionamiento[i][j] != null){
                    System.out.println(estacionamiento[i][j].toString());
                }
            }
        }
        
        //ii. Cual es el piso mas ocupado
        int cantMax=-1;
        int pisoMax=-1;
        int cantxPiso;
        for (int i = 0; i < N; i++) {
            cantxPiso=0;
            for (int j = 0; j < N; j++) {
                if(estacionamiento[i][j]!= null){
                    cantxPiso++;
                }
                if(cantxPiso > cantMax){
                    
                }
            }
        }
        
        
    }
    
}
