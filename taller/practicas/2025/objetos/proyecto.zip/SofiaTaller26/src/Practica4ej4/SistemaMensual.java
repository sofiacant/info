/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica4ej4;

/**
 *
 * @author Sofia C
 */
public class SistemaMensual extends Sistema{
    
    private String[] meses = new String[]{"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
    
    
    public SistemaMensual(int A, int N, Estacion est) {
        super(A, N, est);
    }
    
    public String calcularPromedio(){
        String prom= getEstacion().toString() + ":\n";
        for (int j = 0; j < 12; j++) {
            double suma = 0;
            for (int i = 0; i < getAniosCons(); i++) {
                suma += obtenerTemperatura(i,j);
            }
            double promedio = suma / getAniosCons();
            prom += "- " + meses[j] + ": " +  promedio + " °C \n";
      
    }
          return prom;
    }
    

    public String toString() {
        return super.toString();
    }
    
    
}
