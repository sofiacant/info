
package Practica4ej4;

import javax.xml.stream.XMLInputFactory;

/**
 *
 * @author Sofia C
 */
public class SistemaAnual extends Sistema {

    public SistemaAnual(int A, int N, Estacion est) {
        super(A, N, est);
    }

    public String calcularPromedio(){
        String prom= getEstacion().toString()+ "\n";
        for (int i = 0; i < getAniosCons(); i++) {
            double suma=0;
            for (int j = 0; j < getMeses(); j++) {
                suma+= obtenerTemperatura(i, j);
            }
            double promedio= suma/getMeses();
            prom+= "Año "+ (getAnioA()+i )+ " : "+promedio + "  °C "+ "\n";
        }     
        return prom;
    }
    
    public String toString() {
        return super.toString();
    }
    
    
    
    
    
}
