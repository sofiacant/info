/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica4ej4;

/**
 *
 * @author Sofia C
 */
public abstract class Sistema {
    private int anioA;
    private int aniosCons;
    private double reporte[][];
    private int meses= 12;
    private Estacion estacion;

    public Sistema(int A, int N, Estacion est) {
        this.anioA = A;
        this.aniosCons = N;
        this.estacion = est;
        inicializarReporte();
    }
    
    private void inicializarReporte(){ 
       reporte= new double[aniosCons][meses];
   
        for (int i = 0; i < aniosCons; i++) {
            for (int j = 0; j < meses ; j++) {
                reporte[i][j]=100;
            } 
        }   
    }
    
    public void registrarTemperatura(int mes, int año, double temp){
        reporte[año-anioA][mes-1]= temp;
    }
    
    public double obtenerTemperatura(int mes, int año){
        double temp= reporte[año-this.anioA][mes-1];
        return temp;
    }
    
    public String mayorTemperatura(){
        double maxTemp=-1;
        int añoMax=-1;
        int maxMes=-1;
        for (int i = 0; i < aniosCons; i++) {
            for (int j = 0; j < meses; j++) {
                if(reporte[i][j]> maxTemp){
                    maxTemp= reporte[i][j];
                    maxMes=j;
                    añoMax=i;
                }
            }
        }
        return "El mes con mayor temperatura: "+ (maxMes+1)+ " en el año "+(añoMax+this.anioA);
    }

    public Estacion getEstacion() {
        return estacion;
    }

    public int getAniosCons() {
        return aniosCons;
    }

    public int getAnioA() {
        return anioA;
    }

    public int getMeses() {
        return meses;
    }
    
    
    
    public abstract String calcularPromedio();
    
    
}
