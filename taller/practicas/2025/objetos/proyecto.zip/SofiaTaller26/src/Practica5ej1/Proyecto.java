/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica5ej1;

/**
 *
 * @author Sofia C
 */
public class Proyecto {
    private String nombre;
    private int codigo;
    private String director;
    private Investigador vInvestigadores[];
    private int dimF;
    private int dimL;

    public Proyecto(String nombre, int codigo, String director) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.director = director;
        crearVector();                
        
    }
    
    private void crearVector(){
        this.dimL=0;
        this.dimF=50;
        vInvestigadores= new Investigador[dimF];
    }
    
    public void agregarInvestigador( Investigador unInvestigador){
        vInvestigadores[dimL]= unInvestigador;
        dimL++;
    }
    
    public double dineroTotalOtorgado(){
        double montoT=0;
         for (int i = 0; i < dimL; i++) {
           montoT+= vInvestigadores[i].montoTInvestigador();
        }
        return montoT;
    }

    public void otorgarTodos(String unNombre) {  ///con while    si encontre otorgo todos
        for (int i = 0; i < dimL; i++) {
            if (vInvestigadores[i].getNombreCompleto().equals(unNombre)) {
               vInvestigadores[i].otorgarTodos();
            }
       }
    }
    
    
    @Override
    public String toString() {
        String str= "Proyecto" + "nombre=" + nombre + ", codigo=" + codigo + ", director=" + director+"\n"+
                "Monto total de proyecto:  "+ dineroTotalOtorgado()+"\n"; 
                for (int i = 0; i < dimL; i++) {
                    str+= vInvestigadores[i].toString();
                }
        return str;
    }
    
    
    
    
}
