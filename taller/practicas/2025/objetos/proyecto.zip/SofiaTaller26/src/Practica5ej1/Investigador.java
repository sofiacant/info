
package Practica5ej1;

/**
 *
 * @author Sofia C
 */
public class Investigador {
    private String nombreCompleto;
    private int categoria;
    private String especialidad;
    private Subsidio vSubsidios[];
    private int dimFSub=5;
    private int dimL;

    public Investigador(String nombreCompleto, int categoria, String especialidad) {
        this.nombreCompleto = nombreCompleto;
        this.categoria = categoria;
        this.especialidad = especialidad;
        vSubsidios= new Subsidio[this.dimFSub];
        this.dimL=0;

    }
    
    public void agregarSubsidio(Subsidio unSubsidio){
        vSubsidios[dimL]=unSubsidio;
        //vSubsidios[dimL].setOtorgado(true);  preguntar
        dimL++;
    }
    
    public double montoTInvestigador(){
        double montoT=0;
        for (int i = 0; i < dimL; i++) {
            if(vSubsidios[i].isOtorgado()){
                montoT+= vSubsidios[i].getMonto();
            }
        }
        return montoT;
    }
    
    private boolean cumpleNombre(String nombre){
        boolean aux=false;
        if(this.nombreCompleto.equals(nombre)){
            aux=true;
        }   
        return aux;
    }
    
    public void otorgarTodos(){
        for (int i = 0; i < dimL; i++) {
                if(vSubsidios[i].isOtorgado()== false){
                    vSubsidios[i].setOtorgado(true);
            }
        }
        
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }
    
    
    public String toString() {
        return "Nombre del investigador: "  + nombreCompleto + ", categoria " + categoria 
                + ", especialidad " + especialidad+ "monto total de sus subsidios otorgados: "
                + montoTInvestigador()+ "| \n ";
    }
    
}
