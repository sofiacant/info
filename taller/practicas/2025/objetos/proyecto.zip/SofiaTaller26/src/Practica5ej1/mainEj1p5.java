/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica5ej1;
import PaqueteLectura.GeneradorAleatorio;
/**
 *
 * @author Sofia C
 */
public class mainEj1p5 {


    public static void main(String[] args) {
        GeneradorAleatorio.iniciar();
        Proyecto p = new Proyecto("Proye", 42323, "Maria Sanchez");

        Investigador i1 = new Investigador("Juan", 2, "Laboratorio");
        Investigador i2 = new Investigador("Matias", 5, "Analista");
        Investigador i3 = new Investigador("Soledad", 1, "Investigador");

        Subsidio sInv1 = new Subsidio(555, GeneradorAleatorio.generarString(10));
        Subsidio sInv2 = new Subsidio(654, GeneradorAleatorio.generarString(10));
        
        i1.agregarSubsidio(sInv1);
        i1.agregarSubsidio(sInv2);
        
        Subsidio s2 = new Subsidio(546, GeneradorAleatorio.generarString(10));
        i2.agregarSubsidio(s2);
        
        Subsidio s3 = new Subsidio(435, GeneradorAleatorio.generarString(10));
        i3.agregarSubsidio(s3);

        p.agregarInvestigador(i1);
        p.agregarInvestigador(i2);
        p.agregarInvestigador(i3);

        p.otorgarTodos("Juan");
        System.out.println(p.toString());
    }
    
}
