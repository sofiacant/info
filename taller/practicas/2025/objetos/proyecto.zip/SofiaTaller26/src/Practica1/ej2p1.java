
package Practica1;

/**
 *
 * 
//Paso 1: Importar la funcionalidad para lectura de datos
 * @author Sofia C
 */
import PaqueteLectura.Lector;
public class ej2p1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
  //Paso 2: Declarar la variable vector de double 
        int dF=15;
   
        //Paso 3: Crear el vector para 15 double 
        double [] vector =  new double [dF];
        //Paso 4: Declarar indice y variables auxiliares a usar
        double altura;
        double promedio;
        double altTotal=0;
        int cantP=0;
        //Paso 6: Ingresar 15 numeros (altura), cargarlos en el vector, ir calculando la suma de alturas
        for (int i = 0; i < 15; i++) {
            System.out.println("Ingresar una altura");
            altura= Lector.leerDouble();
            vector[i]= altura;
            altTotal= altTotal+ altura;
        }
        //Paso 7: Calcular el promedio de alturas, informarlo
        promedio= altTotal/dF;
        System.out.println("La altura promedio es: "+ promedio);
        //Paso 8: Recorrer el vector calculando lo pedido (cant. alturas que están por encima del promedio)
        for (int i = 0; i < 15; i++) {
            if(vector[i]> promedio){
                cantP++;
            }
        }
        //Paso 9: Informar la cantidad.
        System.out.println("La cantidad de alturas que superan al promedio es:  "+ cantP);
    }
    
}
