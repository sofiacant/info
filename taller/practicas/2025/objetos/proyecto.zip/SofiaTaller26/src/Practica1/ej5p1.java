
package Practica1;

import PaqueteLectura.Lector;
public class ej5p1 {

    
    public static void main(String[] args) {
      int clientes=5;
      int asp= 4;
      int [][]calificacion = new int[clientes][asp];
      String[] nombresAspectos = {"Atención al cliente", "Calidad de la comida", "Precio", "Ambiente"};
      
        for (int i = 0; i < clientes; i++) {
            for (int j = 0; j < asp; j++) {
                System.out.println("Califica con puntaje del 1 al 10 el aspecto "+j);
                int puntaje= Lector.leerInt();  
                calificacion[i][j]=puntaje;
            }
        }
         
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(calificacion[i][j] + " ");
            }
            System.out.println();
        }
        
        
        

        for (int j = 0; j < asp; j++) {
            int suma=0;
            for (int i = 0; i < clientes; i++) {
                suma+= calificacion[i][j];
                
            }
            double promedio= suma/clientes;
            System.out.println("El promedio del aspecto "+ nombresAspectos[j] +" es "+promedio);
        }
      
      
    }
    
}
