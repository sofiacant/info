/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica1;

import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;

/**
 *
 * @author Sofia C
 */
public class ej3p1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int filas = 5;
        int col = 5;
        int[][] matriz = new int[filas][col];
        GeneradorAleatorio.iniciar();

        //- Escriba un programa que defina una matriz de enteros de tamaño 5x5. 
        //Inicialice la matriz con números aleatorios entre 0 y 30.   
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                int num = GeneradorAleatorio.generarInt(31);
                matriz[i][j] = num;
            }
        }

        //Mostrar el contenido de la matriz en consola.  
        for (int i = 0; i < 5; i++) {
            System.out.println("Fila: " + i);
            for (int j = 0; j < 5; j++) {
                System.out.println(" Columna: " + j + " contiene: " + matriz[i][j]);
            }
        }

        //Calcular e informar la suma de los elementos de la fila 1
        int suma = 0;
        for (int j = 0; j < 5; j++) {
            suma = suma + matriz[1][j];
        }
        System.out.println("La suma de los elementos de la fila 1 es: " + suma);

        //Generar un vector de 5 posiciones donde cada posición j contiene la suma
        //de los elementos de la columna j de la matriz. Luego, imprima el vector. 
        int dimFv = 5;
        int[] vector = new int[dimFv];

        for (int j = 0; j < 5; j++) {
            for (int i = 0; i < 5; i++) {
                vector[i] = vector[i] + matriz[i][j];
            }
        }
        for (int i = 0; i < 5; i++) {
            System.out.println("La posicion " + i + " contiene: " + vector[i]);
        }

        //Leer un valor entero e indicar si se encuentra o no en la matriz. 
//En caso de encontrarse indique su ubicación (fila y columna) 
//en caso contrario imprima “No se encontró el elemento”. 
        System.out.println("Ingrese un valor entero");

        int valor = Lector.leerInt();

        int i = 0;
        int j = 0;
        boolean encontre = false;
        while ((encontre != true) && (i < 5)) {
            while ((encontre != true) && (j < 5) && (i < 5)) {
                if (valor == matriz[i][j]) {
                    encontre = true;
                    System.out.println("Se encontro en la fila: " + i + " columna: " + j);
                } else {
                    j++;
                }
                if (j == 5) {
                    j = 0;
                    i++;
                }

            }
        }
        if (encontre == false) {
            System.out.println("No se encontro el elemento");
        }

    }
}
