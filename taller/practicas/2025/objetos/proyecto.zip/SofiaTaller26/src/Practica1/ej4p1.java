
package Practica1;

import PaqueteLectura.Lector;
public class ej4p1 {

    public static void main(String[] args) {
        int dimF=8;
        int dimC=4;
        int [][]oficinas= new int[dimF][dimC];
        int ofi;
   
        System.out.println("Ingrese un numero de piso de 1 a 8");
        int piso= Lector.leerInt();
        
        while(piso != 9){
            
            System.out.println("Ingrese un numero de oficina");
            ofi= Lector.leerInt();
            oficinas[piso-1][ofi-1]++; 
            
            System.out.println("Ingrese un numero de piso de 1 a 8");
            piso= Lector.leerInt();
        }
        
        for (int i = 0; i < dimF; i++) {
            for (int j = 0; j < dimC; j++) {
                System.out.println("La cantidad de personas que llegaron a la oficina"+ (j+1)+ "del piso "+ (i+1)+ " es "+ oficinas[i][j]);
            }
        }
        
        
        
    }
    
}
