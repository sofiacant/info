package Practica5ej4;
/**
 *
 * @author Sofia C
 */
public class MainMusica {

    public static void main(String[] args) {
        
        Director d1= new Director(10, "Sofia", 34254, 38);
        Director d2= new Director(37, "Juan", 35354, 56);
       
        CoroPorHilera ch1= new CoroPorHilera(2, 2, "HILERA",d1 );
        coroSemicircular ch2= new coroSemicircular(2, "Semicircular", d2);
        
        
        Coristas c1= new Coristas(7, "Lara", 534543, 29);
        Coristas c2= new Coristas(6, "Nicolas", 42376, 45);
        Coristas c3= new Coristas(7, "Matias", 856765, 28);
        Coristas c4= new Coristas(6, "Rosario", 54237, 47);   //Corohileras
        
        Coristas c5= new Coristas(9, "Pilar", 85823, 32);
        Coristas c6= new Coristas(7, "Maria", 83251, 37);   //coro Semicircular
        
        ch1.agregarCorista(c1);
        ch1.agregarCorista(c2);
        ch1.agregarCorista(c3);
        ch1.agregarCorista(c4);
        
        
        ch2.agregarCorista(c5);
        ch2.agregarCorista(c6);
        
        
        System.out.println(ch1.toString());
        
        System.out.println("Esta bien formado?"+ch1.bienFormado());
        
        
        
        System.out.println(ch2.toString());
        
        System.out.println("Esta bien formado?"+ch2.bienFormado());
       
    }
    
}
