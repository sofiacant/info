/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica5ej4;

/**
 *
 * @author Sofia C
 */
public class CoroPorHilera extends Coro{
    private int dimF;
    private Coristas coroHileras[][];
    private int vDim[];
    private int filas;
    private int col;

    public CoroPorHilera(int N, int M, String nombreCoro, Director director) {
        super(nombreCoro, director);
        this.dimF = N;
        this.filas=N;
        this.col=M;
        inicializarVD();
        coroHileras= new Coristas[N][M];
    }

    private void inicializarVD(){
        vDim= new int [dimF];
        for (int i = 0; i < dimF; i++) {
            vDim[i]=0;
        }
    }
    
    public void agregarCorista(Coristas C){
        int i=0;
        boolean agregue=false;
        while((!agregue)&&(i<filas)){
            if(vDim[i]< col){
                coroHileras[i][vDim[i]]=C;
                agregue=true;
                vDim[i]++;
            }else{
                i++;        
        }
        }
    }
    
    public boolean estaLleno(){
        int cant=0;
        for (int i = 0; i < filas; i++) {
            if(vDim[i]== col){
                cant++;
            }
        }
        return (cant== filas);
    }
    
    public boolean bienFormado(){
        boolean ok=true;
        int i=0;
        int j=0;
        int tonoActual;
        while((i< filas)&&(ok)){
            tonoActual=0;
            j=0;
            while((j<col)&(ok)){
                tonoActual= coroHileras[i][j].getTonoFundamental();
                j++;
                if((coroHileras[i][j].getTonoFundamental()== tonoActual)&&(j<col)){
                    j++;
                }
                else{
                    ok=false;
                    i++;
                }
            }   
        }
        int l=0;
        int k=0;
        if(ok){   
            while((k< filas)&&(ok)){
                if(coroHileras[k][l].getTonoFundamental()> coroHileras[k+1][l].getTonoFundamental()){
                    k++;
                }
            }  
        }
        return ok;
    }

    @Override
    public String toString() {
        String aux=super.toString();
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < vDim[i]; j++) {
                aux+= coroHileras[i][j].toString();
            }
        }
        return aux;
    }
    
    
    
    
    
    
}
