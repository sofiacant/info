package Practica5ej4;

/**
 *
 * @author Sofia C
 */
public class Coristas extends Persona{
    private int tonoFundamental;

    public Coristas(int tonoFundamental, String nombre, int dni, int edad) {
        super(nombre, dni, edad);
        this.tonoFundamental = tonoFundamental;
    }

    public int getTonoFundamental() {
        return tonoFundamental;
    }

    @Override
    public String toString() {
        return "Coristas "+ super.toString() +" tono fundamental: " + tonoFundamental+ "\n" ;
    }

    
    
}
