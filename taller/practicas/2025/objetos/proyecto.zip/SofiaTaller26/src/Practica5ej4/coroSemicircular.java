/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica5ej4;

/**
 *
 * @author Sofia C
 */
public class coroSemicircular extends Coro{
    private Coristas coroSemi[];
    private int dimF;
    private int dimL;

    public coroSemicircular(int N, String nombreCoro, Director director) {
        super(nombreCoro, director);
        this.dimF = N;
        this.dimL=0;
        coroSemi= new Coristas[dimF];
    }
    
    
    public void agregarCorista(Coristas c){
        if(dimL<dimF){
            coroSemi[dimL]=c;
            dimL++;
        }
    }
        
   public boolean estaLleno(){
       return (dimL==dimF);
   }
   
   public boolean bienFormado(){
       boolean aux=true;
       int actual=0;
       int i=0;
       while((i<dimL-1)&&(aux)){
           actual= coroSemi[i].getTonoFundamental(); //guardo la 0
           i++;
           if(actual < coroSemi[i].getTonoFundamental()){ 
               aux=false;
           }
       }
       return aux;
   }

    @Override
    public String toString() {
        String str="Coro Semicircular: " + super.toString();
        for (int i = 0; i < dimL; i++) {
            str+= coroSemi[i].toString();
        }
        return str;
    }

}
