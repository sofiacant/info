/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica5ej4;

/**
 *
 * @author Sofia C
 */
public abstract class Coro {
    private String nombreCoro;
    private Director director;
    private int cantCoristas; //dimF

    public Coro(String nombreCoro, Director director) {
        this.nombreCoro = nombreCoro;
        this.director = director;
    }

    public abstract void agregarCorista(Coristas c);
    public abstract boolean estaLleno();
    public abstract boolean bienFormado();
    
    @Override
    public String toString() {
        return "Coro " + nombreCoro + ", director: " + director.toString() + "\n";
    }
    
    
    
    
}
