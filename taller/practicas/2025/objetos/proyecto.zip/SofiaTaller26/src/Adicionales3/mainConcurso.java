/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Adicionales3;

/**
 *
 * @author Sofia C
 */
public class mainConcurso {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Alumno alu1= new Alumno("Sofia", 20, "Piano", 7.1);
        Alumno alu2= new Alumno("Juan", 16, "Guitarra", 6.9);
        Alumno alu3= new Alumno("Mateo", 57, "Trompeta", 9.1);
        Alumno alu4= new Alumno("Lara", 38, "Guitarra", 9.2);
        Alumno alu5= new Alumno("Lucas", 13, "Acordeon", 6.5);
     
        Concurso conc= new Concurso(20);
        
        conc.agregarAlumno(alu1, 5);
        conc.agregarAlumno(alu2, 3);
        conc.agregarAlumno(alu3, 4);
        conc.agregarAlumno(alu4, 2);
        conc.agregarAlumno(alu5, 1);
        
        alu1.asignarPuntaje(9);
        alu2.asignarPuntaje(8);
        alu3.asignarPuntaje(7);
        alu4.asignarPuntaje(5);
        alu5.asignarPuntaje(9);
        
        System.out.println(conc.toString());
    }
    
}
