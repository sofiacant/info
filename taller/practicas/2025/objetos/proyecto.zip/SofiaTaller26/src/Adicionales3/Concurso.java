
package Adicionales3;

/**
 *
 * @author Sofia C
 */
public class Concurso {
    private int N;
    private int dimF=5;
    private Alumno [][]concurso;
    private int []dimLConcurso;

    public Concurso(int N) {
        this.N = N;
        concurso= new Alumno[dimF][N];
        inicializarVC();
       // inicializarMatriz();
    }
    
    private void inicializarVC(){
        dimLConcurso=new int [dimF];
        for (int i = 0; i < dimF; i++) {
            dimLConcurso[i]=0;
        }       
}
    private void inicializarMatriz(){
        for (int i = 0; i < dimF; i++) {
            for (int j = 0; j < N; j++) {
                concurso[i][j]=null;
            }
        }
    }
    
    public void agregarAlumno(Alumno a, int g){
        concurso[g-1][dimLConcurso[g-1]]= a;
        dimLConcurso[g-1]++;
    }
    
    public void asignarPuntajeAlumno(int G, String N, double P){
        boolean existe=false;
        int i=0;
        while(i<dimLConcurso[G-1] && !existe){
            if(concurso[G-1][i].getNombre().equals(N)){
                concurso[G-1][i].asignarPuntaje(P);
            }
            else
                i++;
        }
    }
    
    public Alumno maxAlumno(){
        Alumno aluMax=null;
        double maxPuntaje=-1;
        for (int i = 0; i < dimF; i++) {
            for (int j = 0; j < dimLConcurso[i]; j++) {
                if (concurso[i][j].obtenerPuntaje() > maxPuntaje){
                    maxPuntaje= concurso[i][j].obtenerPuntaje() ;
                    aluMax= concurso[i][j];
                }  
            }
        }
        return aluMax;
    }

    
    public String toString() {
        String aux="Concurso:" + "\n";
        for (int i = 0; i < dimF; i++) {
            aux+= "Genero "+ (i+1) + "- Total inscriptos: "+ dimLConcurso[i] + "\n";
            for (int j = 0; j < dimLConcurso[i]; j++) {
                aux+= "Representacion del alumno "+ (j+1) + " - "+ concurso[i][j].toString()+ "\n";  
            }
        }
        aux+="El alumno de mayor puntaje en todo el concurso es: "+ maxAlumno();
        return aux;
    }

   

       

}