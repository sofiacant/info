
package Adicionales3;

/**
 *
 * @author Sofia C
 */
public class Alumno {
    private String nombre;
    private int edad;
    private String instrumento;
    private double puntaje;

    public Alumno(String nombre, int edad, String instrumento, double puntaje) {
        this.nombre = nombre;
        this.edad = edad;
        this.instrumento = instrumento;
        this.puntaje = puntaje;
    }

    public String getNombre() {
        return nombre;
    }
    
    public double obtenerPuntaje(){
        return this.puntaje;
    }
    
    
    public void asignarPuntaje(double p){
        this.puntaje=p;
    }

    public String toString() {
        return "Alumno " + " nombre: " + nombre + ", edad: " + edad + ", instrumento: " + instrumento + ", puntaje: " + puntaje;
    }
    
    
    
    
}
