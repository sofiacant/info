
package Adicionales4;
/*
 * @author Sofia C
 */
public abstract class Urna {
    private int num;
    private int contBlanco;
    private Zona zona;

    public Urna(int U, Zona Z) {
        this.num = U;
        this.contBlanco = 0;
        this.zona = Z;
    }
    
    public void votarEnBlanco(){
        this.contBlanco++;
    }
    
    public abstract int calcularGanador();
    
    
    public int sumaEnBlanco(){
        return this.contBlanco; 
        
    }

    @Override
    public String toString() {
        return "Urna: " + "nro: " + num +  " Zona: " + zona.toString();
    }
    
    
    
    
}
