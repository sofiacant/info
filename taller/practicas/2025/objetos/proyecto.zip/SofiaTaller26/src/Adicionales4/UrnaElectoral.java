
package Adicionales4;

/**
 *
 * @author Sofia C
 */
public class UrnaElectoral extends Urna{
    private int cantListas;
    private int []contadorVotos;

    public UrnaElectoral(int L, int U, Zona Z) {
        super(U, Z);
        setCantListas(L);
        inicializarVC();
    }

    private void setCantListas(int cantListas) {
        this.cantListas = cantListas;
    }
       
    private void inicializarVC(){
         this.contadorVotos = new int[cantListas];
        for (int i = 0; i < cantListas; i++) {
            contadorVotos[i]= 0;
        }
    }
    
    public boolean validarNumeroDeLista(int N){
        boolean aux=false;
        N=-1;
        if((N>0)&& (N<= cantListas)){
            aux=true;
        }
        return aux;
    }
    
    public void votarPorLista(int L){
        contadorVotos[L]++;
    }
    
    public int devolverVotosPorLista(int L){
        int aux= contadorVotos[L-1]; 
        return aux;
    }
    
    
    public int calcularGanador(){
        int listaWin=-1;
        int cantMax=-999;
        for (int i = 0; i < cantListas; i++) {
            if(contadorVotos[i]> cantMax){
                cantMax=contadorVotos[i];
                listaWin= i;
            }
        }
        return listaWin;
    }
    
    private int sumaTotalListas(){
        int aux=0;
        for (int i = 0; i < cantListas; i++) {
            aux+= contadorVotos[i]; 
        }
        return aux;
    }
    
     public int calcularTotalVotos(){
         int sumaTotal= sumaEnBlanco();
         sumaTotal+= sumaTotalListas();
         
         return sumaTotal;
     }

    @Override
    public String toString() {
        return super.toString()+" Urna Electoral" + "Total votos:" + calcularTotalVotos() + ".Ganador: "+
                calcularGanador();
    }
     
     
}
  
    
    
   
