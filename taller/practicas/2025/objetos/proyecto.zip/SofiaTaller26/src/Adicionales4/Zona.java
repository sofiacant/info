/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Adicionales4;

/**
 *
 * @author Sofia C
 */
public class Zona {
    private String localidad;
    private String partido;
    private String provincia;

    public Zona(String localidad, String partido, String provincia) {
        this.localidad = localidad;
        this.partido = partido;
        this.provincia = provincia;
    }

    @Override
    public String toString() {
        return  localidad + ", " + partido + ", " + provincia;
    }
    
    
    
}
