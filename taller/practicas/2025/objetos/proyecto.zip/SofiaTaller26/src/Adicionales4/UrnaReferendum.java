
package Adicionales4;

/**
 *
 * @author Sofia C
 */
public class UrnaReferendum extends Urna {
    private int contFavor;
    private int contContra;

    public UrnaReferendum( int U, Zona Z) {
        super(U, Z);
        setContFavor(0);
        setContContra(0);
    }
   
    
    public void votarAFavor(){
        this.contFavor++;
    }
    
    public void votarEnContra(){
        this.contContra++;
    }

    private int getContFavor() {
        return contFavor;
    }

    private int getContContra() {
        return contContra;
    }

    public void setContFavor(int contFavor) {
        this.contFavor = contFavor;
    }

    public void setContContra(int contContra) {
        this.contContra = contContra;
    }
    
    public int calcularGanador(){
        int aux=1;
        if(getContContra() == getContFavor()){
            aux=0;
        }else if(getContContra()> getContFavor()){
            aux=-1;
        }
        return aux;
    }
    
    
    public int calcularTotalVotos(){
        int sumaTotal= sumaEnBlanco();
        
        sumaTotal+= getContFavor()+getContContra();
        return sumaTotal;
    }
    
    @Override
    public String toString() {
        return  super.toString()+ "Urna Referendum" + "Total votos:" + this.calcularTotalVotos() + ".Ganador: "+
                this.calcularGanador();
    }
}
