
package Adicionales4;
import PaqueteLectura.Lector;
/**
 *
 * @author Sofia C
 */
public class mainUrnas {

    public static void main(String[] args) {
        Zona z1= new Zona("City Bell", "La plata", "Buenos Aires");
        UrnaElectoral ue= new UrnaElectoral(5, 203, z1);
        
        Zona z2= new Zona("Villa Elisa", "La plata", "Buenos Aires");
        UrnaReferendum ur= new UrnaReferendum(204, z2);
        
        System.out.println("Ingrese siguiente DNI (0 para finalizar):");
        int dni= Lector.leerInt();
        while(dni != 0){
            System.out.println("Ingresar un numero de lista");
            int N= Lector.leerInt();
            if(ue.validarNumeroDeLista(N)){
                ue.votarPorLista(N);
            }else
                ue.votarEnBlanco();
            
            System.out.println("Ingresar un numero M");
            int M= Lector.leerInt();
            if(M>0){
                ur.votarAFavor();
            }
            else if(M<0) ur.votarEnContra();
            else
                ur.votarEnBlanco();
            System.out.println("Ingrese siguiente DNI (0 para finalizar):");
            dni= Lector.leerInt();
            }
        
            System.out.println(ue.toString());
            System.out.println(ur.toString());
        }
    
    
    
       
    
}
