
package Practica5ej2;

/**
 *
 * @author Sofia C
 */
public class Estacionamiento {
    private String nombre;
    private String direccion;
    private int horaApertura;
    private int horaCierre;   
    private int pisos;
    private int plazas;   
    private Auto estacionamiento[][];

    public Estacionamiento(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.horaApertura= 8;
        this.horaCierre=21;
        this.pisos=5;
        this.plazas=10;
        estacionamiento= new Auto[pisos][plazas];//java lo inicializa en null
    }

    public Estacionamiento(String nombre, String direccion, int horaApertura, int horaCierre, int N, int M) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.horaApertura = horaApertura;
        this.horaCierre = horaCierre;
        this.pisos = N;
        this.plazas = M  ;
        estacionamiento= new Auto[pisos][plazas];//java lo inicializa en null
        
    }
    
    
    public void estacionarAuto(Auto a, int X ,int Y){ //x e y son validos y hay lugar
        estacionamiento[X-1][Y-1]= a;        
    }
    
    public String buscarAuto(String patente){
        String str="Auto inexistente";
        int i=0;
        boolean ok=false;
        while((i<pisos)&&(!ok)){
            int j=0;
            while((j<plazas)&&(!ok)){
                if(estacionamiento[i][j] != null){
                 if(estacionamiento[i][j].getPatente().equals(patente)){
                     ok=true; 
                     str="El numero de piso es "+(i+1)+ " en la plaza "+ (j+1);
                 }}
                if(!ok){
                    j++;
                }
            }//sale del while interno
            if(!ok){
                i++;
            }
            }  
   return str;      
}
    
    
    public String representacionEst(){
        String str="";
        for (int i = 0; i < pisos; i++) {
            str+= "Piso "+ (i+1);
            for (int j = 0; j < plazas; j++) {
                str+= " Plaza "+ (j+1);
                if(estacionamiento[i][j] != null){
                    str+=estacionamiento[i][j].toString()+"\n";
                }else {
                    str+= " Auto inexistente "+"\n";}
                            }
                }
        return str;
            }
    
    
    public int cantidadAutosY(int Y){
        int cant=0; 
        for (int i = 0; i < pisos; i++) {
            if(estacionamiento[i][Y-1] != null){
                cant++;
            }
        }
        return cant;
        }
    
    
}
