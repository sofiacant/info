/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica5ej2;
import PaqueteLectura.Lector;
/**
 *
 * @author Sofia C
 */
public class mainej2 {

 
    public static void main(String[] args) {
       Estacionamiento est= new Estacionamiento("Aura", "45 5 y 6", 9, 20, 3, 3);
       
       Auto au1= new Auto("Sofia", "asd123");
       Auto au2= new Auto("Alma", "awq823");
       Auto au3= new Auto("Mora", "uyi765");
       Auto au4= new Auto("Juan", "aju213");
       Auto au5= new Auto("Jose", "jyh645");
       Auto au6= new Auto("Lautaro", "gdf543");
       
       est.estacionarAuto(au1, 1, 2);
       est.estacionarAuto(au2, 3, 2);
       est.estacionarAuto(au3, 2, 2);
       est.estacionarAuto(au4, 3, 1);
       est.estacionarAuto(au5, 1, 3);
       est.estacionarAuto(au6, 2, 1);
       
        System.out.println(est.representacionEst());
        
        System.out.println(est.cantidadAutosY(1));
        
        
        System.out.println("Ingrese una patente");
        String patente= Lector.leerString();
        
        System.out.println(est.buscarAuto(patente));
 
    }
    
}
