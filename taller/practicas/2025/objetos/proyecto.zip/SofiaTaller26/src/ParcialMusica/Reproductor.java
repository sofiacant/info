
package ParcialMusica;

/**
 *
 * @author Sofia C
 */
public class Reproductor {
    private Cancion reproductor[][];
    private int N;
    private int M;
    private int ultCancion;
    private int dimL[];

    public Reproductor(int N, int M) {
        this.N = N;
        this.M = M;
        reproductor= new Cancion[N][M];
        this.ultCancion=0;
        inicializarVD();
    }
    
    private void inicializarVD(){
        dimL= new int[N];
        for (int i = 0; N < 10; i++) {
            dimL[i]=0;
        }
    }
    
    public boolean quedaEspacio(int nro_lista){
        boolean aux=false;
        if(dimL[nro_lista-1]<M)
            aux=true;
        return aux;
    }
    
    public void almacenarCancion(Cancion can, int lista){
        reproductor[lista-1][dimL[lista-1]]= can;
        dimL[lista-1]++;
        ultCancion++;
    }
    
    public void reproducir(int lista, int C){  //reproduccion de c canciones
         
    }
    
    
    
            
}
