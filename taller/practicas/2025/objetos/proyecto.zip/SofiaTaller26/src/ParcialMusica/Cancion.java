/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialMusica;

/**
 *
 * @author Sofia C
 */
public class Cancion {
    private String titulo;
    private String interprete;
    private int duracion;

    public Cancion(String titulo, String interprete, int duracion) {
        this.titulo = titulo;
        this.interprete = interprete;
        this.duracion = duracion;
    }
    
    
    public String reproducir(){
        return "Titulo: "+this.titulo+ " ,interprete: "+this.interprete+ " ,duracion: "+this.duracion;
    }
    
    
    
    
    
}
