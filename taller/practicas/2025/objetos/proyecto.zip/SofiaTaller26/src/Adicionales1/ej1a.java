
package Adicionales1;
import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;

public class ej1a {

    public static void main(String[] args) {
        int dimF= 5;
        int dimC= 10;
        
        boolean [][]estac= new boolean[dimF][dimC];
        
        for (int i = 0; i < dimF; i++) {
            for (int j = 0; j < dimC; j++) {
                 estac[i][j]= false;
            }
        }
        
        GeneradorAleatorio.iniciar();
        int patente= GeneradorAleatorio.generarInt(30);
        while(patente!= 0){
            System.out.println("Ingrese el numero de piso");
            int piso=GeneradorAleatorio.generarInt(5); //Lector.leerInt();
            System.out.println(piso);
            System.out.println("Ingrese el numero de plaza");
            int plaza=GeneradorAleatorio.generarInt(10); //Lector.leerInt();
            System.out.println(plaza);
            estac[piso][plaza]= true;           //sin el -1 por el aleatorio, por teclado si -1
            
           patente= GeneradorAleatorio.generarInt(30);
            
 
        }
        
        //imprimir
        for (int i = 0; i < dimF; i++) {
            System.out.println("Piso "+ i);
            for (int j = 0; j < dimC; j++) {
                System.out.print  (estac[i][j] +"  |");
            }
        }
        
        
        int cant=0;
        int cantMax=-1;
        int filaMax=-1;
        
        for (int i = 0; i < dimF; i++) {
            cant=0;
            for (int j = 0; j < dimC; j++) {
                if(estac[i][j] == true){
                    cant+=1;
                }
            if(j==dimC){
                if(cant> cantMax){
                    cantMax=cant;
                    filaMax=i;
                }
            }
            }
        }
        
        
        
    }
    
}
