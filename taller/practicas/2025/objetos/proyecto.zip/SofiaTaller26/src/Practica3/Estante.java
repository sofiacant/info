
package Practica3;

/**
 *
 * @author Sofia C
 */
public class Estante {
    private int dimL=0;
    private int dimF=20;
    private Libro []estante;

    public Estante() {
        estante =new Libro[dimF];

    }
    public Estante(int N){
        estante= new Libro[N];
    }
    
    public boolean estaLleno(){
        return (dimL==dimF);
    }
    
    public boolean agregarLibro(Libro l){
        boolean aux=false;
        if(!estaLleno()){
            estante[dimL]=l;
            dimL++;
            aux=true;
        }
        else
            System.out.println("No es posible, esta lleno");
        return aux;
    }
    
    public int cantidadLibros(){
        return dimL;
    }
    
    
    public Libro buscarLibro(String titulo){
        int i=0;
        Libro unLibro = null;
        while((i<dimL)&&(unLibro==null)){
            if(estante[i].getTitulo().equals(titulo)){
               unLibro= estante[i];
            }else{
                       i++;
                       }
        }
        return unLibro;
    }
    
    
    
    
    
}
