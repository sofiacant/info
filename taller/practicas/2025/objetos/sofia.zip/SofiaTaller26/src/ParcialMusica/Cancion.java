
package ParcialMusica;

/**
 *
 * @author Sofia C
 */
public class Cancion {
    private String titulo;
    private String interprete;
    private int duracion;

    public Cancion(String titulo, String interprete, int duracion) {
        this.titulo = titulo;
        this.interprete = interprete;
        this.duracion = duracion;
    }

    public String getInterprete() {
        return interprete;
    }

    public int getDuracion() {
        return duracion;
    }
    
    public String reproducir(){
        return "Titulo: "+this.titulo+ " ,interprete: "+this.interprete+ " ,duracion: "+this.duracion;
    }

}
