
package ParcialMusica;
import PaqueteLectura.GeneradorAleatorio;
import PaqueteLectura.Lector;
/**
 *
 * @author Sofia C
 */
public class mainMusica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GeneradorAleatorio.iniciar();
        Reproductor rep= new Reproductor(3, 15); 
        
        Cancion c1= new Cancion("cancion1", "gsfsd fdssd", 60);
        Cancion c2= new Cancion("cancion2", "gdfgf terte", 80);
        Cancion c3= new Cancion("cancion3", "ewre yrtyr", 120);
        Cancion c4= new Cancion("cancion4", "gsgsd jyy", 60);
        Cancion c5= new Cancion("cancion5", "dasdsa asas", 40);
        
        Cancion cc1= new Cancion("cancion1l2", "uykj fdssd", 240);
        Cancion cc2= new Cancion("cancion2l2", "gjty fdssd", 300);
        Cancion cc3= new Cancion("cancion3l2", "gvdvd fdssd",78);
        Cancion cc4= new Cancion("cancion4l2", "nhnhg fdssd", 100);
        Cancion cc5= new Cancion("cancion5l2", "sadas fdssd", 110);
        Cancion cc6= new Cancion("cancion6l2", "mnbmb fdssd", 120);
        Cancion cc7= new Cancion("cancion7l2", "cxzvxz fdssd", 150);
        Cancion cc8= new Cancion("cancion8l2", "uyty fdssd", 132);
        Cancion cc9= new Cancion("cancion9l2", "eweqw fdssd", 185);
        Cancion cc10= new Cancion("cancion10l2", "gsfsd fdssd", 156);
        
        Cancion ccc1= new Cancion("cancion1l3", "gsfsd fdssd", 122);
        Cancion ccc2= new Cancion("cancion2l3", "gsfsd fdssd", 187);
        Cancion ccc3= new Cancion("cancion3l3", "gsfsd fdssd", 123);
        Cancion ccc4= new Cancion("cancion4l3", "gsfsd fdssd", 122);
        Cancion ccc5= new Cancion("cancion5l3", "gsfsd fdssd", 154);
        Cancion ccc6= new Cancion("cancion6l3", "gsfsd fdssd", 123);
        Cancion ccc7= new Cancion("cancion7l3", "gsfsd fdssd", 187);
        Cancion ccc8= new Cancion("cancion8l3", "gsfsd fdssd", 199);
        Cancion ccc9= new Cancion("cancion9l3", "gsfsd fdssd", 187);
        Cancion ccc10= new Cancion("cancion10l3", "gsfsd fdssd", 188);
        Cancion ccc11= new Cancion("cancion11l3", "gsfsd fdssd", 177);
        Cancion ccc12= new Cancion("cancion12l3", "gsfsd fdssd", 196);
        Cancion ccc13= new Cancion("cancion13l3", "gsfsd fdssd", 169);
        Cancion ccc14= new Cancion("cancion14l3", "gsfsd fdssd", 168);
        Cancion ccc15= new Cancion("cancion15l3", "gsfsd fdssd", 145);
        
        
        rep.almacenarCancion(c1, 1);
        rep.almacenarCancion(c2, 1);
        rep.almacenarCancion(c3, 1);
        rep.almacenarCancion(c4, 1);
        rep.almacenarCancion(c5, 1);
        
        
        rep.almacenarCancion(cc1, 2);
        rep.almacenarCancion(cc2, 2);
        rep.almacenarCancion(cc3, 2);
        rep.almacenarCancion(cc4, 2);
        rep.almacenarCancion(cc5, 2);
        rep.almacenarCancion(cc6, 2);
        rep.almacenarCancion(cc7, 2);
        rep.almacenarCancion(cc8, 2);
        rep.almacenarCancion(cc9, 2);
        rep.almacenarCancion(cc10, 2);
        
        rep.almacenarCancion(ccc1, 3);
        rep.almacenarCancion(ccc2, 3);
        rep.almacenarCancion(ccc3, 3);
        rep.almacenarCancion(ccc4, 3);
        rep.almacenarCancion(ccc5, 3);
        rep.almacenarCancion(ccc6, 3);
        rep.almacenarCancion(ccc7, 3);
        rep.almacenarCancion(ccc8, 3);
        rep.almacenarCancion(ccc9, 3);
        rep.almacenarCancion(ccc10, 3);
        rep.almacenarCancion(ccc11, 3);
        rep.almacenarCancion(ccc12, 3);
        rep.almacenarCancion(ccc13, 3);
        rep.almacenarCancion(ccc14, 3);
        rep.almacenarCancion(ccc15, 3);
       
        for (int i = 0; i < 5; i++) {
            int L= GeneradorAleatorio.generarInt(3)+1;
            int N= GeneradorAleatorio.generarInt(6);
            rep.reproducir(L,N);
            
        }
        String interprete= Lector.leerString();
        System.out.println(rep.reproducir(interprete));
        
        System.out.println("La duracion total es: "+ rep.calcularDuracionTotal());
        
    }
    
}
