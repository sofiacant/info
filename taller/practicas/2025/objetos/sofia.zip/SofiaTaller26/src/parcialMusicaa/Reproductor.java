/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialMusicaa;

/**
 *
 * @author Sofia C
 */
public class Reproductor {
    
    private Cancion reproductor[][];
    private int N;  //cantidad de listas
    private int M;  //DIMF Canciones por Lista
    private int dimL[];
    private int[] ultCancion; // Un puntero por cada lista

    public Reproductor(int N, int M) {
        this.N = N;
        this.M = M;
        reproductor= new Cancion[N][M];
        inicializarVectores();
    }
    
    private void inicializarVectores(){
        dimL= new int[N];
        ultCancion= new int[N];
        for (int i = 0; i < N; i++) {
            dimL[i]=0;
            ultCancion[i]=0;
        }
    }
    
    public boolean quedaEspacio(int nro_lista){
        boolean aux=false;
        if(dimL[nro_lista-1]<M)
            aux=true;
        return aux;
    }
    
    public void almacenarCancion(Cancion can, int lista){
        reproductor[lista-1][dimL[lista-1]]= can;
        dimL[lista-1]++;
        
    }
    
   // public void reproducir3(int lista, int C){  //reproduccion de c canciones
   //     for (int i = 0; i < C; i++) {   
   //         System.out.println(reproductor[lista-1][ultCancion+1].toString());
   //         ultCancion++;
    //        if(ultCancion == dimL[lista-1]){
    //            ultCancion=0;
    //        }
  //  }
  //  }
    
    public void reproducir(int lista, int c){ //reprod la sig cancion a la ult reproducida
        int cant=0;
        int L= lista-1;
        while(cant< c){
                System.out.println(reproductor[L][ultCancion[L]].toString());
                ultCancion[L]++;  //avanzo a la sig cancion
                cant++; 
                if(ultCancion[L] == dimL[L]) {
                    ultCancion[L]=0;
                }
        }
    }
    
    public String reproducir(String interprete){
        String aux="";
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < dimL[i]; j++) {
                    if(reproductor[i][j].getInterprete().equals(interprete)){
                        aux+= reproductor[i][j].toString()+ "\n";
                    }
            }   
        }
        return aux;
    }
    
    public int calcularDuracionTotal(){
        int total=0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < dimL[i]; j++) {
                total+= reproductor[i][j].getDuracion();
            }
        }
        return total;
    }
         
}


