 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialGNC;

/**
 *
 * @author Sofia C
 */
public class Surtidor {
    private boolean fueraServicio;
    private Venta vVentas[];
    private int dimFVenta;

    public Surtidor(int V) {
        this.dimFVenta = V;
        this.fueraServicio=true;
        vVentas= new Venta[dimFVenta]; //java lo inicializa en null
    }
    
    
     
}
