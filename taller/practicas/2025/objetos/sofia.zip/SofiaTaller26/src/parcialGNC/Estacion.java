 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialGNC;

/**
 *
 * @author Sofia C
 */
public class Estacion {
    private String direccion;
    private double preciom3;
    private int dimF;
    private Surtidor vSurtidor[];

    public Estacion(String direccion, double preciom3, int maxVentas) {
        this.direccion = direccion;
        this.preciom3 = preciom3;
        this.dimF=6;
        crearVS(maxVentas);
        
    }
    
    private void crearVS(int maxVentas){
        vSurtidor= new Surtidor[dimF];
        //java lo inicializa en null
        for (int i = 0; i < dimF; i++) {
            vSurtidor[i]= new Surtidor(maxVentas);
        }
        
    }
    
    
}
