/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialGNC;

/**
 *
 * @author Sofia C
 */
public class Venta {
    private int dniCli;
    private int cantM3Carga;
    private double monto;
    private String medioPago;
}
