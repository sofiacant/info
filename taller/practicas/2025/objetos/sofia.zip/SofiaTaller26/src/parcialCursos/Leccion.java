/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialCursos;

/**
 *
 * @author Sofia C
 */
public class Leccion {
    private String tema;
    private String fecha;
    private int duracion;

    public Leccion(String tema, String fecha, int duracion) {
        this.tema = tema;
        this.fecha = fecha;
        this.duracion = duracion;
    }

    public int getDuracion() {
        return duracion;
    }

    @Override
    public String toString() {
        return "Leccion " + " tema: " + tema + ", fecha: " + fecha + ", duracion: " + duracion + "\n";
    }
    
    
    
}

