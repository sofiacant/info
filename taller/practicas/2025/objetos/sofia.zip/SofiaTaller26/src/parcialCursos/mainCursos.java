
package parcialCursos;

/**
 *
 * @author Sofia C
 */
public class mainCursos {

   
    public static void main(String[] args) {
        
        CursoOnline co= new CursoOnline("Zoom", "Curso 1 ", 7000, 5);
        
        CursoPresencial cp= new CursoPresencial(2, true, "Curso 2 ", 8000, 4);
        
        
        Leccion l1= new Leccion("Vector", "12/10", 100);
        Leccion l2= new Leccion("Listas", "15/10", 120);
        Leccion l3= new Leccion("Estructuras", "16/10", 35);
        Leccion l4= new Leccion("Registros", "19/10", 30);
        Leccion l5= new Leccion("Arboles", "20/10", 60);
        Leccion l6= new Leccion("Grafos", "22/10", 79);
        Leccion l7= new Leccion("Matriz", "25/10", 90);
        
        co.agregarLeccion(l1);
        co.agregarLeccion(l2);
        co.agregarLeccion(l3);
        co.agregarLeccion(l4);
        
        cp.agregarLeccion(l5);
        cp.agregarLeccion(l6);
        cp.agregarLeccion(l7);
        
        System.out.println(co.toString());
        
        System.out.println(cp.toString());
    }
    
}
