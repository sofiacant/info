/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialCursos;

/**
 *
 * @author Sofia C
 */
public class CursoPresencial extends Cursos{
    private int aula;
    private boolean coffeeBreak;

    public CursoPresencial(int aula, boolean coffeeBreak, String nombreCurso, double costoLeccion, int N) {
        super(nombreCurso, costoLeccion, N);
        this.aula = aula;
        this.coffeeBreak = coffeeBreak;
    }
    
     public double costoFinal(){
        double costo=costoLecciones();
        if(coffeeBreak){
            costo+= (costo*0.05); 
        }
        return costo;
    }
     
    @Override
    public String toString() {
        return " Presencial " + super.toString();
    }
            
}
