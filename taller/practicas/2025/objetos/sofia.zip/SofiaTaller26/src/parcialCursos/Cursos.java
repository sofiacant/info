/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialCursos;

/**
 *
 * @author Sofia C
 */
public abstract class Cursos {
    private String nombreCurso;
    private double costoLeccion;
    private Leccion vLecciones[];
    private int dimF;
    private int dimL;

    public Cursos(String nombreCurso, double costoLeccion, int N) {
        this.nombreCurso = nombreCurso;
        this.costoLeccion = costoLeccion;
        this.dimF = N;
        this.dimL=0;
        crearVector();
    }
    
    private void crearVector(){
        vLecciones= new Leccion[dimF];
        //java lo inicializa en null;
    }
    
    public void agregarLeccion(Leccion l){
        if(dimL<dimF){
            vLecciones[dimL]=l;
            dimL++;
        }
    }
    
    public double costoLecciones(){
        return (this.dimL* this.costoLeccion);
    }
    
    public abstract double costoFinal();

    @Override
    public String toString() {
        String str=" nombre: " + nombreCurso ;
        for (int i = 0; i < dimL; i++) {
            str+= vLecciones[i].toString();
        }
        str+= " Costo final de inscripcion" + this.costoFinal();
        return str;
    }
    
    
    
}
