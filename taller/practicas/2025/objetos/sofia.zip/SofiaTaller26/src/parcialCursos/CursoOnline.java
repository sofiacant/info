/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcialCursos;

/**
 *
 * @author Sofia C
 */
public class CursoOnline extends Cursos{
    private String plataforma;

    public CursoOnline(String plataforma, String nombreCurso, double costoLeccion, int N) {
        super(nombreCurso, costoLeccion, N);
        this.plataforma = plataforma;
    }
    
    public void agregarLeccion(Leccion l){
        if(l.getDuracion()<= 45){
            super.agregarLeccion(l);
        }
    }
    
    public double costoFinal(){
        double costo=costoLecciones();
        if(plataforma.equals("Zoom")){
            costo-= (costo*0.10); 
        }
        return costo;
    } 

    @Override
    public String toString() {
        return " Online " + super.toString();
    }

    
}
