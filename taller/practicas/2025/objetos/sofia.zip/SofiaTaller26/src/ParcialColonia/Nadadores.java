  
  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialColonia;

/**
 *
 * @author Sofia C
 */
public class Nadadores extends Grupo {
    private String nombreBañero;
    private double sueldoBañero;

    public Nadadores(String nombreBañero, double sueldoBañero, String nombre, double sueldoInst, double costoInscripcion, int N) {
        super(nombre, sueldoInst, costoInscripcion, N);
        this.nombreBañero = nombreBañero;
        this.sueldoBañero = sueldoBañero;
    }
    
    
    public boolean agregarChico(Chico c){  //asumo que hay espacio
        boolean aux=false;
        if(c.isSabeNadar()){
            aux= super.agregarChico(c);
        }
        return aux;
    }
    
    public double obtenerGananciaNeta(){
        double aux= super.gananciaGrupo();
        aux-= sueldoBañero;
        return aux;
    }

    public boolean esRentable(){
        return (obtenerGananciaNeta()>5000000);
    }
    
    @Override
    public String toString() {
        return "Nadadores " +super.toString() ;
    }
    
    
    
}
