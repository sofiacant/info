/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialColonia;

/**
 *
 * @author Sofia C
 */
public class Chico {
    private String nombre;
    private int telefono;
    private boolean sabeNadar;

    public Chico(String nombre, int telefono, boolean sabeNadar) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.sabeNadar = sabeNadar;
    }

    public boolean isSabeNadar() {
        return sabeNadar;
    }

    @Override
    public String toString() {
        return "Chico: " + "nombre: " + nombre + ", telefono: " + telefono + ", sabe nadar: " + sabeNadar + "\n";
    }
    
    
    
    
}
