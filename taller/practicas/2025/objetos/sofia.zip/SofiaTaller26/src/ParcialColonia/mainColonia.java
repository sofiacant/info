/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialColonia;

/**
 *
 * @author Sofia C
 */
public class mainColonia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Nadadores nad= new Nadadores("JUan", 10000, "Matias", 12000, 2500, 6);
       
       Exploradores exp= new Exploradores(1500, "Jose", 13000, 3000, 5);
       
       Chico c1=new Chico("Lara", 43223, true);
       Chico c2=new Chico("Lorenzo", 465645, true);
       Chico c3=new Chico("Pilar", 487876, false);
       Chico c4=new Chico("Sol", 432665, true);
       Chico c5=new Chico("Maria", 47284, true);
       Chico c6=new Chico("Tomas", 4321312, true);
       Chico c7=new Chico("Damian", 436365, false);
       Chico c8=new Chico("Nano", 4645765, true);
       
       
       nad.agregarChico(c1);
       nad.agregarChico(c2);
       nad.agregarChico(c3);
       nad.agregarChico(c4);
       nad.agregarChico(c5);
       
       
       exp.agregarChico(c6);
       exp.agregarChico(c7);
       exp.agregarChico(c8);
       
       
        System.out.println( nad.toString());
        
        
        System.out.println( exp.toString());
        
        System.out.println("Es rentable? "+ exp.esRentable());
        
        System.out.println("Es rentable? "+ nad.esRentable());
    }
    
}
