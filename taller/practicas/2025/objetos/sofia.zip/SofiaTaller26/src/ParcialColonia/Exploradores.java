/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialColonia;

/**
 *
 * @author Sofia C
 */
public class Exploradores extends Grupo{
    private double costoAlquiler;

    public Exploradores(double costoAlquiler, String nombre, double sueldoInst, double costoInscripcion, int N) {
        super(nombre, sueldoInst, costoInscripcion, N);
        this.costoAlquiler = costoAlquiler;
    }
    
     public double obtenerGananciaNeta(){
        double aux= super.gananciaGrupo();
        aux-= costoAlquiler;
        return aux;
    }
    
    public boolean esRentable(){
        return (obtenerGananciaNeta()>5000000);
    }
     
    @Override
    public String toString() {
        return "Exploradores " +super.toString() ;
    }
}
