/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialColonia;

/**
 *
 * @author Sofia C
 */
public abstract class Grupo {
    private String nombre;
    private double sueldoInst;
    private double costoInscripcion;
    private Chico vChicos[];
    private int dimF;
    private int dimL;

    public Grupo(String nombre, double sueldoInst, double costoInscripcion, int N) {
        this.nombre = nombre;
        this.sueldoInst = sueldoInst;
        this.costoInscripcion = costoInscripcion;
        this.dimF = N;
        this.dimL=0;
        vChicos= new Chico[dimF]; //java lo inicializa en null
    }
    
    public boolean agregarChico(Chico c){
        boolean aux=false;
        vChicos[dimL]=c;
        dimL++;     
        return aux;
    }
    
    public double gananciaGrupo(){
        double ganancia=((dimL*costoInscripcion)-sueldoInst);
        return ganancia;
    }
    
    public abstract double obtenerGananciaNeta();
    public abstract boolean esRentable();
    
    
    @Override
    public String toString() {
        String str= "Nombre del instructor: " + nombre + ", cantidad de chicos: " + dimL + "\n";
        for (int i = 0; i < dimL; i++) {
            str+= vChicos[i].toString()+ "\n";
        }
        str+= obtenerGananciaNeta();
        return  str;
    }
    
    
    
    
       
    
    
}
