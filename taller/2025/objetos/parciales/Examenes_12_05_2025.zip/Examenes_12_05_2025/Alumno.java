/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Parciales.Examenes_12_05_2025;

/**
 *
 * @author valen
 */
public class Alumno {

    private String nombre;
    private String apellido;
    private String legajo;
    private Examen[] examenes;
    private int dimF;
    private int dimL;

    public Alumno(String nombre, String apellido, String legajo, int M) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.legajo = legajo;
        setExamenes(M);
    }

    public void setExamenes(int M) {
        this.dimF = M;
        this.dimL = 0;
        examenes = new Examen[dimF];
    }

    public void setExamen(Examen E) {
        examenes[dimL] = E;
        dimL++;
    }

    public String getLegajo() {
        return legajo;
    }

    public int revisarExamenes(int mes, int año, String modalidad) {
        int cant = 0;
        for (int i = 0; i < dimL; i++) {
            if ((examenes[i].getMes() == mes) && (examenes[i].getAño() == año) && (examenes[i].getModalidad().equals(modalidad))) {
                cant++;
            }
        }
        return cant;
    }
    
    public double calcularPromedio (){
        double prom;
        double total=0;
        for (int i =0; i<dimL;i++){
            total+=examenes[i].getCalificacion();
        }
        prom=((double)(total/dimL));
        return prom;
    }
    
    public String toString (){
        return "Nombre: "+this.nombre+" Apellido: "+this.apellido;
    }

}
