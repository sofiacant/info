/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Parciales.Examenes_12_05_2025;

import java.util.HashSet;

/**
 *
 * @author valen
 */
public class Universidad {

    private Alumno[] alumnos;
    private int dimF;
    private int dimL;

    public Universidad(int N) {
        setAlumnos(N);
    }

    public void setAlumnos(int N) {
        this.dimL = 0;
        this.dimF = N;
        alumnos = new Alumno[N];
    }

    public boolean agregarAlumno(Alumno A) {
        boolean aux = false;
        if (dimL < dimF) {
            alumnos[dimL] = A;
            dimL++;
            aux = true;
        }
        return aux;
    }

    public int posicionAlumno(String legajo) {
        int pos = 0;
        for (int i = 0; i < dimL; i++) {
            if (alumnos[i].getLegajo().equals(legajo)) {
                pos = i;
            }
        }
        return pos;
    }

    public boolean agregarExamen(String legajo, Examen E) {
        boolean aux = false;    
        int pos = posicionAlumno(legajo);
        if (pos != -1) {
            alumnos[pos].setExamen(E);
            aux = true;
        }
        return aux;
    }

    public int cantExamenesRendidos(int mes, int año, String modalidad) {
        int cant = 0;
        for (int i = 0; i < dimL; i++) {
            cant+= (alumnos[i].revisarExamenes(mes, año, modalidad));
        }
        return cant;
    }

    public String mejorPromedio() {
        String str = "";
        double promedio;
        double promedioMax = -1;
        for (int i = 0; i < dimL; i++) {
            promedio = alumnos[i].calcularPromedio();
            if (promedio > promedioMax) {
                promedioMax = promedio;
                str = alumnos[i].toString();
            }
        }
        return str + " Promedio: "+promedioMax;
    }

}
