/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialBauleras;

/**
 *
 * @author Sofia C
 */
public class Cliente {
    private int dni;
    private String nombreCliente;
    private int telefono;
    private String localidad;
    private boolean tieneSeguro;

    public Cliente(int dni, String nombreCliente, int telefono, String localidad, boolean tieneSeguro) {
        this.dni = dni;
        this.nombreCliente = nombreCliente;
        this.telefono = telefono;
        this.localidad = localidad;
        this.tieneSeguro = tieneSeguro;
    }

    public String getLocalidad() {
        return localidad;
    }

    public boolean isTieneSeguro() {
        return tieneSeguro;
    }
    
    
    
    
    
    @Override
    public String toString() {
        return " Dni " + dni + ", nombre cliente " + nombreCliente + ", telefono " + telefono + ", localidad " + localidad + ", tiene seguro " + tieneSeguro + "\n";
    }
    
    
    
    
}
