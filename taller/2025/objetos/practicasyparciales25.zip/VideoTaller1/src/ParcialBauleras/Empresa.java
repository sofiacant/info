package ParcialBauleras;

/**
 *
 * @author Sofia C
 */
public class Empresa {

    private String nombreEmpresa;
    private String direccion;
    private double costoPorMes;
    private Cliente[][] bauleraClientes;
    private int sectores;  //filas
    private int bauleras; //columnas
    private int dimLSector;
    private int dimLBaulera;

    public Empresa(String direccion, double costoPorMes, int S, int B) {
        this.nombreEmpresa = "Storage";
        this.direccion = direccion;
        this.costoPorMes = costoPorMes;
        this.sectores = S;
        this.bauleras = B;
        this.dimLBaulera = 0;
        this.dimLSector = 0;
        crearBaulera();
    }

    private void crearBaulera() {
        bauleraClientes = new Cliente[sectores][bauleras];
    }

    public boolean ingresarCliente(Cliente c) {
        if (dimLSector < sectores) {
            if (dimLBaulera < bauleras) {
                bauleraClientes[dimLSector][dimLBaulera] = c;
                dimLBaulera++;
                if (dimLBaulera == bauleras) {
                    dimLBaulera = 0;
                    dimLSector++;
                }
            }
        }
        return true;
    }

    public String listarClientesLH(int sectorX) {
        String str = "";
        for (int j = 0; j < bauleras; j++) {
            Cliente cli = bauleraClientes[sectorX - 1][j];
            if (cli.getLocalidad().equals("Los Hornos")) {
                str += cli.toString() + "\n";
            }
        }
        return "Clientes de Los Hornos del sector: " + sectorX + str+  "\n";
    }

    public int sectorMasClientesAsegurado() {
        int sectorMax = -1;
        int maxClientes = -1;
        int cantCli = 0;
        for (int i = 0; i < sectores; i++) {
            cantCli = 0;
            for (int j = 0; j < bauleras; j++) {
                if (bauleraClientes[i][j].isTieneSeguro()) {
                    cantCli++;
                }

            }
            if (cantCli > maxClientes) {
                maxClientes = cantCli;
                sectorMax = i;
            }
        }
        return sectorMax;
    }

    @Override
    public String toString() {
        String aux = "";
        for (int i = 0; i < sectores; i++) {
            aux += "Sector " + (i + 1) + ": " + "\n";
            for (int j = 0; j < bauleras; j++) {
                aux += "Baulera " + (j + 1) + bauleraClientes[i][j].toString() + "\n";
            }
        }

        return "Empresa: " + "Nombre " + nombreEmpresa + "- Direccion " + direccion + "- Costo por mes " + costoPorMes + "\n" + aux;
    }

}
