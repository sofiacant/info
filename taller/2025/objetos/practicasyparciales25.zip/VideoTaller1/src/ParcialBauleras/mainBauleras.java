/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialBauleras;

/**
 *
 * @author Sofia C
 */
public class mainBauleras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Empresa e= new Empresa("49 y 10", 1000, 5, 3);
        
        Cliente c1= new Cliente(5443, "Sofia", 22154, "La Plata", true);
        Cliente c2=new Cliente(5343, "Valen", 322654, "Los Hornos", true);
        Cliente c3= new Cliente(42534, "Mati", 654654, "Ensenada", true);
        Cliente c4= new Cliente(42534, "Thelma", 654654, "Ensenada", true);
        Cliente c5= new Cliente(42534, "Orne", 654654, "Los Hornos", true);
        Cliente c6= new Cliente(42534, "Jota", 65465, "La Plata", true);
        Cliente c7= new Cliente(42534, "Nico", 798789, "Los Hornos", true);
        Cliente c8= new Cliente(42534, "Max", 62423, "Los Hornos", true);
        Cliente c9= new Cliente(42534, "Iara", 6876, "La plata", false);
        Cliente c10= new Cliente(42534, "Eva", 6432, "La plata", false);
        Cliente c11= new Cliente(42534, "Juan", 654654, "La plata", true);
        Cliente c12= new Cliente(42534, "Marta", 6213214, "La plata", false);
        Cliente c13= new Cliente(42534, "Maria", 65966, "Los Hornos", false);
        Cliente c14= new Cliente(42534, "Mariano", 6549787, "La plata", true);
        Cliente c15= new Cliente(42534, "Gonzalo", 653213, "Los Hornos", false);
        
        
        e.ingresarCliente(c1);
        e.ingresarCliente(c2);
        e.ingresarCliente(c3);
        e.ingresarCliente(c4);
        e.ingresarCliente(c5);
        e.ingresarCliente(c6);
        e.ingresarCliente(c7);
        e.ingresarCliente(c8);
        e.ingresarCliente(c9);
        e.ingresarCliente(c10);
        e.ingresarCliente(c11);
        e.ingresarCliente(c12);
        e.ingresarCliente(c13);
        e.ingresarCliente(c14);
        e.ingresarCliente(c15);
        
        
        System.out.println(e.listarClientesLH(1));
        
        System.out.println(e.sectorMasClientesAsegurado());
        
        System.out.println(e.toString());
        
    }
    
}
