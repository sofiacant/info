/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialFuncionTeatro;

/**
 *
 * @author Sofia C
 */
public class Butaca {

    private String descriptor;
    private double precio;
    private boolean ocupada;

    public Butaca(int fila, int columna) {
        this.ocupada = false;
        this.precio = (800 + (100 * fila));
        this.descriptor = "Butaca " + fila + " , " + columna;
    }

    public void ocuparButaca(boolean ocupado) {
        this.ocupada = ocupado;
    }

    public boolean isOcupada() {
        return ocupada;
    }

    public double getPrecio() {
        return precio;
    }

    @Override
    public String toString() {
        return "| Descriptor " + descriptor + ", precio " + precio + ", ocupada " + ocupada +"\n";
    }
    
    

}
