/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialFuncionTeatro;

/**
 *
 * @author Sofia C
 */
public class MainFuncionTeatro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcion f= new Funcion("Abracadabra", 10, 15, 5, 5);
        
        f.ocuparButaca(1, 1);
        f.ocuparButaca(1, 2);
        f.ocuparButaca(2, 2);
        f.ocuparButaca(2, 1);
        f.ocuparButaca(3, 1);
        f.ocuparButaca(3, 3);
 
        System.out.println(f);
        
        f.desocuparButacas(2);
        System.out.println(f);
        
        System.out.println(f.representaciones(1));
        
        System.out.println(f.toString());
        
    }
    
}
