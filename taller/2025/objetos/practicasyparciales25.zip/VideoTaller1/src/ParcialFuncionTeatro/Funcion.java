/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialFuncionTeatro;

/**
 *
 * @author Sofia C
 */
public class Funcion {

    private String titulo;
    private int fecha;
    private int hora;
    private Butaca[][] sala;
    private int filas;
    private int columnas;

    public Funcion(String titulo, int fecha, int hora, int N, int M) {
        this.titulo = titulo;
        this.fecha = fecha;
        this.hora = hora;
        this.filas = N;
        this.columnas = M;
        setSala();
    }

    private void setSala() {
        sala = new Butaca[filas][columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                sala[i][j] = new Butaca(i, j);
            }

        }
    }

    public double ocuparButaca(int B, int F) {
        double precio = sala[F - 1][B - 1].getPrecio();
        if (!sala[F - 1][B - 1].isOcupada()) {
            sala[F - 1][B - 1].ocuparButaca(true);
        }
        return precio;
    }

    public void desocuparButacas(int F) {
        for (int j = 0; j < columnas; j++) {
            if (sala[F - 1][j].isOcupada()) {
                sala[F - 1][j].ocuparButaca(false);
            }
        }
    }

    public String representaciones(int B) {
        String aux="";
        for (int i = 0; i < filas; i++) {
            aux+= sala[i][B - 1].toString();
        }
        return aux;
    }

    @Override
    public String toString() {
        String aux="";
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
               aux+= sala[i][j].toString();
            }
        }
    return "Titulo " + titulo + ", fecha " + fecha + ", hora " + hora + aux;
    
    }   
}
