
package Parcialpsicologa;

public class MainAgenda {


    public static void main(String[] args) {
        Agenda a=new Agenda();
        Paciente p1= new Paciente("Orne", true, 5676);
        Paciente p2= new Paciente("Iara", false, 5343);
        Paciente p3= new Paciente("Valen", false, 87667);
        Paciente p4= new Paciente("Nico", false, 5437);
        Paciente p5= new Paciente("Thelma", true, 6546);
        Paciente p6= new Paciente("Mati", true, 1000);
        Paciente p7= new Paciente("Sofia", true, 1500);
        
        a.agendarPaciente(p1,1,3);
        a.agendarPaciente(p2,2,3);
        a.agendarPaciente(p3,4,5);
        a.agendarPaciente(p4,2,6);
        a.agendarPaciente(p5,5,6);
        a.agendarPaciente(p6,4,4);
        a.agendarPaciente(p7,1,2);
        
        
        
        System.out.println(a.liberarTurnos("Sofia"));
        
 
        System.out.println(a.tieneTurno(2, "Iara"));
        System.out.println(a.tieneTurno(3, "Iara"));
    }
    
}
