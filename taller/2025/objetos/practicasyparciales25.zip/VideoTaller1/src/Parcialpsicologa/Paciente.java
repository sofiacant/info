
package Parcialpsicologa;

public class Paciente {
    private String nombre;
    private boolean tieneObra;
    private double costo;

    public Paciente(String nombre, boolean tieneObra, double costo) {
        this.nombre = nombre;
        this.tieneObra = tieneObra;
        this.costo = costo;
    }

    public String getNombre() {
        return nombre;
    }
    
    
}
