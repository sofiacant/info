/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Parcialpsicologa;


public class Agenda {
    private Paciente [][]agenda;
    private int filas; //dias
    private int columnas;

    public Agenda() {
        this.filas = 5;
        this.columnas = 6;
        setAgenda();
    }
    
    private void setAgenda(){
       agenda = new Paciente[filas][columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                agenda[i][j]=null;
            }
        }
    }
    
    public void agendarPaciente(Paciente p,int D, int T){
        agenda[D-1][T-1]=p;
    }
    
    public boolean liberarTurnos(String nombre){
        boolean pudo=false;
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if((agenda[i][j]!=null) &&  (agenda[i][j].getNombre().equals(nombre))){
                    agenda[i][j]=null;
                    pudo=true;
                }
            }
            
        }
 
        return pudo;
    }
     
   // public boolean estaVacio(int f, int c){
    //    boolean vacio=false;
    //    if(agenda[f-1][c]== null){
    //       vacio=true;
    //    }
   //    return vacio;
   // }
    
    public boolean tieneTurno(int D, String nombre){
        boolean tiene=false;
        for (int j = 0; j < columnas; j++) {
            if((agenda[D-1][j]!=null) &&(agenda[D-1][j].getNombre().equals(nombre))){
                tiene=true;
            }
        }
        return tiene;
    }
    
}
