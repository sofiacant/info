package ParcialCursos;

public class CursoBasico extends Curso {

    public CursoBasico(String nombre, double costoInscripcion, String fechaComienzo, int M) {
        super(nombre, costoInscripcion, fechaComienzo, M);
    }

    public Alumno aluConMejorDesempeño() {
        int cantMax = -1;
        int pos=-1;
        for (int i = 0; i < getDimL(); i++) {
            if (getAlumno(i).getCantTareas() > cantMax) {
                cantMax = getAlumno(i).getCantTareas();
                pos=i;
            }

        }
        return getAlumno(pos);
    }
    
    
    
}