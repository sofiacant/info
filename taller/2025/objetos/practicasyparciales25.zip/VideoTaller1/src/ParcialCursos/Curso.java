
package ParcialCursos;

public abstract class Curso {
    private String nombre;
    private double costoInscripcion;
    private String fechaComienzo;
    private Alumno []vAlumnos;
    private int dimF;
    private int dimL;

    public Curso(String nombre, double costoInscripcion, String fechaComienzo, int M) {
        this.nombre = nombre;
        this.costoInscripcion = costoInscripcion;
        this.fechaComienzo = fechaComienzo;
        this.dimF= M;
        this.dimL=0;
        crearVector();
    }
    
    private void crearVector(){
        vAlumnos = new Alumno [dimF];
    }

    public int getDimL() {
        return dimL;
    }
    
    public int agregarAlumno(Alumno a){
        vAlumnos[dimL]=a;
        dimL++;
        return dimL;
    }
    
    public Alumno obtenerAlumno(int A){
        return vAlumnos[A-1];
    }
    
    public void actualizarRendimiento(String nombreAlu,double X){
        for (int i = 0; i < dimL; i++) {
            if (vAlumnos[i].getNombreAlumno().equals(nombreAlu)){
                
            }
        }
    }

    public abstract Alumno aluConMejorDesempeño();
    
    public Alumno getAlumno(int x){
        return vAlumnos[x];
    }
    
    @Override
    public String toString() {
        
        return "Nombre " + nombre + ", costo de inscripcion " +
                costoInscripcion + ", fechaComienzo " + fechaComienzo +"\n"+
                this.aluConMejorDesempeño().toString();
    }
   
}
