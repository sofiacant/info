/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ParcialCursos;

/**
 *
 * @author Sofia C
 */
public class CursoAvanzado extends Curso {
    private String descripcion;

    public CursoAvanzado(String descripcion, String nombre, double costoInscripcion, String fechaComienzo, int M) {
        super(nombre, costoInscripcion, fechaComienzo, M);
        this.descripcion = descripcion;
    }
    
    public Alumno aluConMejorDesempeño(){
        double promMax = -1;
        int pos=-1;
        for (int i = 0; i < getDimL(); i++) {
            if(getAlumno(i).calcularPromedio()> promMax){
                promMax= getAlumno(i).calcularPromedio();
                pos=i;
            }
        }
        return getAlumno(pos);
    }
  
    
    
}
