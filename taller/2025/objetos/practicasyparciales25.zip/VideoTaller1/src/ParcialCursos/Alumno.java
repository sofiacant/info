
package ParcialCursos;


public class Alumno {
    private String nombreAlumno;
    private int cantTareas;
    private int sumaTotal;

    public Alumno(String nombreAlumno) {
        this.nombreAlumno = nombreAlumno;
        this.cantTareas=0;
        this.sumaTotal=0;
    }

    public String getNombreAlumno() {
        return nombreAlumno;
    }

    public int getCantTareas() {
        return cantTareas;
    }
    
    public double calcularPromedio(){
        return (double) sumaTotal/cantTareas;
    }
    
    
    public boolean actualizarAlu(String nombreAlu,double X){
        cantTareas++;
        sumaTotal+=X;
        return true;
    }

    @Override
    public String toString() {
        return "Alumno " + "nombre de alumno " + nombreAlumno + ", cantidad de tareas " + cantTareas + ", suma total " + sumaTotal ;
    }
        
    
    
}
