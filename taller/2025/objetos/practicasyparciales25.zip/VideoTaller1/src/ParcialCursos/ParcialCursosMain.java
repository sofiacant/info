
package ParcialCursos;

public class ParcialCursosMain {

   
    public static void main(String[] args) {
       CursoBasico cb= new CursoBasico("Mate1", 1000, "25/10", 4);
       
       CursoAvanzado cA= new CursoAvanzado("conocimiento", "mate3", 1500, "28/11", 3);
       
       Alumno a1= new Alumno("Sofia");
       Alumno a2= new Alumno("Thelma");
       Alumno a3= new Alumno("Valen");
       Alumno a4= new Alumno("Jota");
       Alumno a5= new Alumno("Mati");
       
       
       cb.agregarAlumno(a1);
       cb.agregarAlumno(a5);
       
       cA.agregarAlumno(a2);
       cA.agregarAlumno(a3);
       cA.agregarAlumno(a4);
       
       
       a2.actualizarAlu("Thelma", 10);
       a5.actualizarAlu("Mati", 10);
       a5.actualizarAlu("Mati", 25);
       
       
        System.out.println(cb.toString());
        System.out.println(cA.toString());
    }
    
}
