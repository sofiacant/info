
package Parcialegresados;
import PaqueteLectura.GeneradorAleatorio;
public class MainEstad {

    public static void main(String[] args) {
        GeneradorAleatorio.iniciar();
        // TODO code application logic here
        Estadisticaanual ea = new Estadisticaanual("CARRERA1", "UNLP1", 2025,2);
        EstadisticaTrimestral et = new EstadisticaTrimestral("CARRERA2", "UNLP2", 2026, 3);
        for (int iAño = 0; iAño < 2; iAño++) {
            for (int iTrimestre = 0; iTrimestre < 4; iTrimestre++) {
                ea.setCantidadEgresados(iAño,iTrimestre,GeneradorAleatorio.generarInt(10) );
            }
        }
        System.out.println(" Mostrar estadistica anual ");
        for (int iAño = 0; iAño < 2; iAño++) {
            for (int iTrimestre = 0; iTrimestre < 4; iTrimestre++) {
                System.out.println(ea.getEgresados(iAño, iTrimestre) );
            }
        }
        System.out.println("---");
        System.out.println("egresados del año 1:"+ea.getEgresadosPorAño(0));
        
        
        for (int iTrimestre = 0; iTrimestre < 4; iTrimestre++) {
            for (int iAño = 0; iAño < 3 ; iAño++) {
               et.setCantidadEgresados(iAño,iTrimestre,GeneradorAleatorio.generarInt(10) );
            }
        }
        System.out.println(" Mostrar estadistica trimestre ");
        for (int iTrimestre = 0; iTrimestre < 4; iTrimestre++) {
            for (int iAño = 0; iAño < 3 ; iAño++) {
               System.out.println(et.getEgresados(iAño, iTrimestre) );
            }
        }
         System.out.println("egresados del trimestre 1:"+ea.getEgresadosPorTrimestre(0));
         System.out.println("--- to strings");
         System.out.println(ea.toString()); System.out.println("...");
         System.out.println(et.toString());
    }
    
}

    

