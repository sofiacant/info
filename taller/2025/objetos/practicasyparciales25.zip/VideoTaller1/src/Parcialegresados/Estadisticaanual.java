/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Parcialegresados;

public class Estadisticaanual extends Sistema {
    
    public Estadisticaanual(String nombreCarrera, String facultad, int añoCreacion, int N) {
        super(nombreCarrera, facultad, añoCreacion, N);
    }
    
    @Override
    public String toString(){
        String aux="";
        for (int iAño = 0; iAño < getDfAÑos(); iAño++) {
            for (int iTrimestre = 0; iTrimestre < getDfTrimestre(); iTrimestre++) {
                int añoTexto = getAñoEdicion()+ iAño;
                aux+= "Año :" + añoTexto + getEgresadosPorAño(iAño) + "egresados;";
            }
        }
        return aux;
    }
}


