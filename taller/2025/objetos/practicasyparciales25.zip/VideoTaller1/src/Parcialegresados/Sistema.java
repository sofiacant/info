
package Parcialegresados;

public abstract class Sistema {
    private String nombreCarrera;
    private String facultad;
    private int añoCreacion;
    private int [][] egresados;
    private int dfTrimestres;
    private int dfAños;
    
    public Sistema(String nombreCarrera, String facultad, int añoCreacion, int N) {
        this.nombreCarrera = nombreCarrera;
        this.facultad = facultad;
        this.añoCreacion = añoCreacion;
        this.dfAños=N;
        this.dfTrimestres=4;
        this.inicializarMatriz();
    }
    public int getDfAÑos(){
        return this.dfAños;
    }
    public int getDfTrimestre(){
        return this.dfTrimestres;
    }
    
    public int getAñoEdicion(){
        return this.añoCreacion;
    }
    public int getCantidadEgresados(int año, int trimestre){
        return this.egresados[año][trimestre];
    }
    
    public int getEgresadosPorAño (int año){
        int acumulado=0;
        for (int iTrimestre = 0; iTrimestre < this.dfTrimestres; iTrimestre++) {
            acumulado+= this.egresados[año][iTrimestre];
        }
        return acumulado;
    }
    
    public int getEgresadosPorTrimestre (int trimestre){
        int acumulado=0;
        for (int iAño = 0; iAño < this.dfAños; iAño++) {
            acumulado+= this.egresados[iAño][trimestre];
        }
        return acumulado;
    }
    
    public int getCantidadTrimestres(int egresados){
        int cantTrimestres=0;
        for (int iAño = 0; iAño < this.dfAños; iAño++) {
            for (int iTrimestre = 0; iTrimestre < this.dfTrimestres; iTrimestre++) {
                if (egresados == this.egresados[iAño][iTrimestre]){
                    cantTrimestres++;
                }
            }
        }
        return cantTrimestres;
    }
    
    public int getEgresados(int año, int mes){
        return this.egresados[año][mes];
    }
    public void setCantidadEgresados(int año,int trimestre, int cantidad){
        this.egresados[año][trimestre]=cantidad;
    }
    
    private void inicializarMatriz(){
        this.egresados= new int [this.dfAños][this.dfTrimestres];
        for (int iAño = 0; iAño < this.dfAños; iAño++) {
            for (int iTrimestre = 0; iTrimestre < this.dfTrimestres; iTrimestre++) {
                this.egresados[iAño][iTrimestre]=-1;
            }
        }
    }
    
    @Override
    public String toString(){
        return this.nombreCarrera + "Plan :" + this.añoCreacion + "Facultad de "+ this.facultad + "\n" +
                this.toString()
        ;
    }
}


