/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Parcialegresados;

public class EstadisticaTrimestral extends Sistema {

    public EstadisticaTrimestral(String nombreCarrera, String facultad, int añoCreacion, int N) {
        super(nombreCarrera, facultad, añoCreacion, N);
    }
    @Override
    public String toString(){
        String aux="";
        for (int iTrimestre = 0; iTrimestre < getDfTrimestre(); iTrimestre++) {
            for (int iAño = 0; iAño < getDfAÑos(); iAño++) {
                int trimestreTexto = iTrimestre+1;
                aux+= "Trimestre :" + trimestreTexto + getEgresadosPorTrimestre(iAño) + "egresados;";
            }
        }
        return aux;
    }

}


